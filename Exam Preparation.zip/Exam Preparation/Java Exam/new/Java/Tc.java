public class Tc {
    public static void main(String[] args) {
        double b=12.5;
        int i =(int)b;

        int x = 12;
        long x1=x;
        double y1 = x;
        System.out.println(x);
        System.out.println(x1);
        System.out.println(y1);
        System.out.println(i);
        System.out.println(b);

    }
}