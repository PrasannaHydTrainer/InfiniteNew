public class P4 {
    public static void main(String[] args) {
        byte b1 = -100;
        int i1 = b1;
        System.out.println(i1);
        int i = 1;
        byte b;
        i = 666;
        b = (byte)i;
        System.out.println(b);
     //   Byte bs=new Byte(55);
       // int i1 = bs.intValue();
      //  int y1 = (Integer)b1;
     //   System.out.println(y1);
        byte bss = (byte)257;
        int is = b &500;
        System.out.println(bss);

    }
}