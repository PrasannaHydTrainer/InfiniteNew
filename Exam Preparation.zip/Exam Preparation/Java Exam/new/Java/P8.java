public class P8 {
    public static float temp() {
        static float sum =21;
        return --sum;
    }

    public static void main(String[] args) {
        temp();
    }
}