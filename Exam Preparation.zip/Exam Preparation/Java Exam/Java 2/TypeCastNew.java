public class TypeCastNew {
    public static void main(String[] args) {
        float b=6.0f;
        int i =(int)b;

        int x=12;
        byte p =(byte)x; 
        System.out.println(p);
    }
}