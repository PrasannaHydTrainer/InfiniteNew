public class Prog18 {
    public static void main(String[] args) {
        test(101); 
        // test(new Integer(101));
    }
    
      public static void test(Float lObject) {
        System.out.println("Long =" + lObject);
      }
    
      // public static void test(long lValue) {
      //   System.out.println("long=" + lValue);
      // }
}