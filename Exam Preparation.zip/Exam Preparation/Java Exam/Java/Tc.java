public class Tc {
    public static void main(String[] args) {
        double b=12.5;
        int i =(int)b;

        float x = 12;
        double y1 = x;
        long x1=y1;
        // System.out.println(y1);
        System.out.println(x1);
        

    }
}