public class P36 {
    public static void main(String[] args) {
        if (null==null) {
            System.out.println("Hi");
        } else {
            System.out.println("Bye");
        }
    }
}