﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inhc
{
    internal class C2 : C1
    {
        public C2()
        {
            Console.WriteLine("Derived Class Constructor...");
        }
    }
}
