﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inhc
{
    internal class C1
    {
        public C1()
        {
            Console.WriteLine("Base Class Constructor...");
        }
    }
}
