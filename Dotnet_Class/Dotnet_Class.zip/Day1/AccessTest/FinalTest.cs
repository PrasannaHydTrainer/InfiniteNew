﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessTest
{
    public class FinalTest : clsAccessModifiers.Demo
    {
        public void Display()
        {
            FinalTest obj = new FinalTest();
            obj.
        }
    }
}
