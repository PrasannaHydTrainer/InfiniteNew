﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StcEx
{
    internal static class Test
    {
        public static void Show()
        {
            Console.WriteLine("Show Method...");
        }

        public static void Topic()
        {
            Console.WriteLine("C# Training is going on...");
        }
    }
}
