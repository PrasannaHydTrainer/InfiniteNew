﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseCon
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ayush obj = new Ayush(1, "Ayush", 88323);
            Console.WriteLine(obj);
        }
    }
}
