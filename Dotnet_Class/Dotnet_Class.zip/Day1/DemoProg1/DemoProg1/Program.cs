﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProg1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Demo obj = new Demo(); 
            obj.SayHello();
            obj.Trainer();
       //     Console.ReadKey();
        }
    }
}
