﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InhDemo
{
    internal class Second : First
    {
        public void Display()
        {
            Console.WriteLine("From Display Method...");
        }
    }
}
