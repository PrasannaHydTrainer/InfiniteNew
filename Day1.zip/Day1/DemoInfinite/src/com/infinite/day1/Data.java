package com.infinite.day1;

public class Data {
	
	public void gowtham() {
		System.out.println("Hi I am Goutham...");
	}
	
	private  void javed() {
		System.out.println("Hi I am Javed...");
	}
	
	void gaurav() {
		System.out.println("Hi I am Gaurav...");
	}
}
