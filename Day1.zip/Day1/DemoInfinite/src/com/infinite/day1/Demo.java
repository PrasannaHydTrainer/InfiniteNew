package com.infinite.day1;

public class Demo {

	public static void main(String[] args) {
		Data obj = new Data();
		obj.gaurav();
		obj.gowtham();
	}
}
