package com.infinite.cols;

public class Customer {

	int custId;
	String name;
	String city;
	double premium;
	
	
}
