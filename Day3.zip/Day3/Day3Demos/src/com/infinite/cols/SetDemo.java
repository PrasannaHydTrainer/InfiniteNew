package com.infinite.cols;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		Set names = new HashSet();
		names.add("Bharvavi");
		names.add("Javed");
		names.add("Akhila");
		names.add("Virdhil");
		names.add("Naveen");
		names.add("Likhitha");
		names.add("Bharvavi");
		names.add("Javed");
		names.add("Akhila");
		names.add("Virdhil");
		names.add("Naveen");
		names.add("Likhitha");
		names.add("Bharvavi");
		names.add("Javed");
		names.add("Akhila");
		names.add("Virdhil");
		names.add("Naveen");
		names.add("Likhitha");
		names.add("Bharvavi");
		names.add("Javed");
		names.add("Akhila");
		names.add("Virdhil");
		names.add("Naveen");
		for (Object ob : names) {
			System.out.println(ob);
		}
	}
}
