package com.infinite.day2;

public class Quiz2 {

	public static void main(String[] args) {
		String str="Hello";
		str.concat(" World");
		System.out.println(str);
	}
}
