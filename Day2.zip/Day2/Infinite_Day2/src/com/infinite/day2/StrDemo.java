package com.infinite.day2;

public class StrDemo {
	public static void main(String[] args) {
		String s1="Yeshwanth", s2="Naveen", s3="Vardhil",s4="Yeshwanth";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
