package com.infinite.day2;

public class Student {

	int sno;
	String name;
	String city;
	double cgp;
	
}
