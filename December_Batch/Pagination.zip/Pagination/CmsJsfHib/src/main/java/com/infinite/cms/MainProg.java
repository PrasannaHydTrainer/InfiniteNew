package com.infinite.cms;

public class MainProg {

	public static void main(String[] args) {
		new CustomerDAOImpl().showHistory();
	}
}
