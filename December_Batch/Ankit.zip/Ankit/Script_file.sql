SELECT * FROM cmsinfinitenew.otp;

truncate table otp;

alter table otp add npassword varchar(50);