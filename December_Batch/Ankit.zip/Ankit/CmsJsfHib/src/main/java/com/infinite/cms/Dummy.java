package com.infinite.cms;

public class Dummy {

	public static void main(String[] args) {
		System.out.println(CustomerDAOImpl.getAlphaNumericString());
	}
}
