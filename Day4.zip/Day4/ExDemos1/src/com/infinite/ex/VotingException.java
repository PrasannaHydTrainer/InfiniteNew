package com.infinite.ex;

public class VotingException extends Exception {

	public VotingException(String error) {
		super(error);
	}
}
