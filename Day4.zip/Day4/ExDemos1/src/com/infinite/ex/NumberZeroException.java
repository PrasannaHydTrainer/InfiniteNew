package com.infinite.ex;

public class NumberZeroException extends Exception {

	public NumberZeroException(String error) {
		super(error);
	}
}
