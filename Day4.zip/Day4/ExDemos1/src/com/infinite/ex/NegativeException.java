package com.infinite.ex;

public class NegativeException extends Exception {

	public NegativeException(String error) {
		super(error);
	}
}
