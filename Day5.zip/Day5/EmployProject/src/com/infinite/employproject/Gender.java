package com.infinite.employproject;

public enum Gender {

	MALE, FEMALE
}
