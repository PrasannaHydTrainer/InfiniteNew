package com.infinite.task;

public class Employee {

}
