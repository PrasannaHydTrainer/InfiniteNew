package com.infinite.task;

public class Department {

	private int departmentId;
}
