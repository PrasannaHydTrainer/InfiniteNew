package com.infinite.task;

import java.util.List;
import java.util.Map;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public List<Employee> getEmployeeStartwith(String startCh) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getSumOfAllEmployees() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getSumOfAllEmployeesGreaterThanAge(int age) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Map<Integer, List> getMapOfDepartmentIdAndEmployeesList(String departmentName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> showEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

}
